import 'dart:convert';
import 'dart:ffi';
import 'dart:io' show File;
import 'dart:convert' show json;
import 'dart:io';

class StringConstant
{
  static const String table = "Clasificación";
  static const String nextgame = "Siguiente partido";
  static const String local = "Local";
  static const String away = "Visitante";
  static const String egarafutsal = "Egara Futsal 2019, C.F. SALA";
  static const String pts = "Pts";
  static const String h = 'h';
  static const String team = "Equipo";
  static const String teams = "Equipos";
  static const String players = "Jugadoras";
  static const String player = "Jugadora";
  static const String journeys = "Jornadas";
}
