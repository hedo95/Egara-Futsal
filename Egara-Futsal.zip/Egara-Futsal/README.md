# Egara-Futsal
This mobile app will give us all data about the league being Female Senior Egara Futsal as club. We'll be able to know better our rivals, their goals, their players, the position of table, and much more.

Enjoy developing this project!
